

import doctormanagementsystem.admitPatient;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AdmitPatientTest {

    @Test
    public void testAddTwoNumbers() {
        admitPatient instance = new admitPatient();

        // Test case 1
        int result1 = instance.addTwoNumbers(2, 3);
        assertEquals(5, result1);

        // Test case 2
        int result2 = instance.addTwoNumbers(-1, 1);
        assertEquals(0, result2);

        // Add more test cases as needed
    }
}
