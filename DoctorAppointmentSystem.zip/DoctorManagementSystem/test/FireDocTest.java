
import doctormanagementsystem.fireDoc;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class FireDocTest {

    @Test
    public void testDeleteDoctorRecord() {
        fireDoc instance = new fireDoc();

        // Assuming that the delete operation is successful
        String doctorIdToDelete = "123"; // Replace with the actual doctor ID to be deleted
        instance.deleteDoctorRecord(doctorIdToDelete);

        // Add assertions to check the state after deletion
        // For example, check if a success message is displayed
        // You may need to modify the code to expose the necessary methods or properties for testing
    }
}
